# Contribuições

Este é um repositório **proprietário** da MJ Cloud Tecnologia.

Pull Requests e contribuições externas **não são aceitas** neste momento,
pois o código-fonte é propriedade exclusiva da empresa.

Se você encontrou um bug ou tem uma sugestão, entre em contato:

📧 **contato@mjcloud.com.br**

---

© 2026 MJ Cloud Tecnologia. Todos os direitos reservados.
